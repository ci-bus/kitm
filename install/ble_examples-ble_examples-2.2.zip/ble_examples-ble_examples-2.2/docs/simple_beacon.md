
Purpose / Scope
===============

This project will demonstrate the implementation of a beacon that uses iBeacon technology. 


The specifications and instructions for using the project can be found here: [SWRA475] (http://www.ti.com/lit/pdf/swra475)
