
Purpose / Scope
===============

This project will demonstrate the implementation of a beacon that uses the Eddystone beacon format. 


A backgrond on and introduction to Bluetooth low energy beacons can be found here: [SWRA475] (http://www.ti.com/lit/pdf/swra475)

The specifications and instructions on using the simple_eddystone project in particular can be found here: [SWRA491] (http://www.ti.com/lit/pdf/swra491)